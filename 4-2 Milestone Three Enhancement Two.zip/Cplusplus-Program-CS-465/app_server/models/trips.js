/**
 * Trip Model
 *
 * Defines the schema for travel destinations stored in MongoDB.
 * Enhanced with validation to improve data integrity and maintainability.
 *
 * Author: Noah Johnson
 * Course: CS-499
 */

const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({

    code: {
        type: String,
        required: [true, 'Trip code is required'],
        trim: true,
        uppercase: true,
        minlength: 3,
        maxlength: 10
    },

    name: {
        type: String,
        required: [true, 'Trip name is required'],
        trim: true,
        minlength: 3,
        maxlength: 50
    },

    length: {
        type: String,
        required: [true, 'Trip length is required'],
        trim: true,
        maxlength: 30
    },

    resort: {
        type: String,
        required: [true, 'Resort name is required'],
        trim: true,
        maxlength: 50
    },

    perPerson: {
        type: String,
        required: [true, 'Price is required'],
        trim: true
    },

    image: {
        type: String,
        required: [true, 'Image filename is required'],
        trim: true
    },

    description: {
        type: String,
        required: [true, 'Description is required'],
        trim: true,
        maxlength: 500
    }

}, {
    timestamps: true
});

// Export the Trip model
module.exports = mongoose.model('Trip', tripSchema);