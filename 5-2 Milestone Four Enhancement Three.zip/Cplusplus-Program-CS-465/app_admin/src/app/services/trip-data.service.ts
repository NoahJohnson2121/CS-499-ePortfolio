/**
 * Trip Data Service
 *
 * Handles communication between the Angular SPA
 * and the Travlr Getaways REST API.
 *
 * Improvements:
 * - Added TypeScript typing
 * - Improved documentation
 * - Centralized API configuration
 * - Improved maintainability
 * - Added reusable authentication headers
 *
 * Author: Noah Johnson
 * Course: CS-499
 */

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AuthenticationService } from './authentication.service';


export interface Trip {

  code: string;
  name: string;
  resort: string;
  perPerson: number;
  image: string;
  description: string;

}


@Injectable({
  providedIn: 'root'
})
export class TripDataService {


  private readonly apiUrl = 'http://localhost:3000/api/trips';


  constructor(
    private http: HttpClient,
    private auth: AuthenticationService
  ) {}


  /**
   * Creates HTTP headers containing JWT authentication token.
   */
  private getHeaders() {

    const token = this.auth.getToken();


    return {

      headers: new HttpHeaders({

        Authorization: `Bearer ${token}`

      })

    };

  }



  /**
   * Retrieves all available trips.
   */
  getTrips(): Observable<Trip[]> {

    return this.http.get<Trip[]>(
      this.apiUrl,
      this.getHeaders()
    );

  }



  /**
   * Retrieves a single trip by trip code.
   */
  getTripByCode(code: string): Observable<Trip> {

    return this.http.get<Trip>(
      `${this.apiUrl}/${code}`,
      this.getHeaders()
    );

  }



  /**
   * Creates a new trip.
   */
  addTrip(trip: Trip): Observable<Trip> {

    return this.http.post<Trip>(
      this.apiUrl,
      trip,
      this.getHeaders()
    );

  }



  /**
   * Updates an existing trip.
   */
  updateTrip(code: string, trip: Trip): Observable<Trip> {

    return this.http.put<Trip>(
      `${this.apiUrl}/${code}`,
      trip,
      this.getHeaders()
    );

  }



  /**
   * Deletes a trip by trip code.
   */
  deleteTrip(code: string): Observable<any> {

    return this.http.delete(
      `${this.apiUrl}/${code}`,
      this.getHeaders()
    );

  }

}