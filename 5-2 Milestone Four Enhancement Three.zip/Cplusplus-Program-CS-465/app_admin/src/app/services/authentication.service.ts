/**
 * Authentication Service
 *
 * Handles user login, JWT token storage,
 * authentication state checking, and logout
 * functionality for the Travlr Getaways SPA.
 *
 * Improvements:
 * - Added documentation
 * - Added typed responses
 * - Improved maintainability
 * - Added centralized API URL
 *
 * Author: Noah Johnson
 * Course: CS-499
 */

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


interface LoginResponse {

  success?: boolean;
  message?: string;
  token: string;

}


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {


  private readonly apiUrl = 'http://localhost:3000/api/users';


  constructor(private http: HttpClient) {}


  /**
   * Authenticates a user and retrieves a JWT token.
   */
  login(email: string, password: string): Observable<LoginResponse> {

    return this.http.post<LoginResponse>(
      `${this.apiUrl}/login`,
      {
        email,
        password
      }
    );

  }


  /**
   * Stores JWT token after successful login.
   */
  saveToken(token: string): void {

    localStorage.setItem('token', token);

  }


  /**
   * Retrieves stored JWT token.
   */
  getToken(): string | null {

    return localStorage.getItem('token');

  }


  /**
   * Determines whether a user is authenticated.
   */
  isLoggedIn(): boolean {

    return this.getToken() !== null;

  }


  /**
   * Removes JWT token and logs user out.
   */
  logout(): void {

    localStorage.removeItem('token');

  }

}