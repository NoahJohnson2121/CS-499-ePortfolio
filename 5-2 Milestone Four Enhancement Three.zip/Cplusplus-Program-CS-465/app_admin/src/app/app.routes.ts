import { Routes } from '@angular/router';

import { LoginComponent } from './login/login';
import { TripListing } from './trip-listing/trip-listing';
import { AuthGuard } from './auth-guard';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'trips', component: TripListing, canActivate: [AuthGuard] }
];