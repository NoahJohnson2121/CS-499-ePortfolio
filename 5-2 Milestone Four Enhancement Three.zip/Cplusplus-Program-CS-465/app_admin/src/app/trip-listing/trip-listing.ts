import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TripCard } from '../trip-card/trip-card';
import { TripDataService } from '../services/trip-data.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-listing.html',
  styleUrls: ['./trip-listing.css']
})
export class TripListing implements OnInit {

  private tripDataService = inject(TripDataService);
  private authService = inject(AuthenticationService);

  // Stores all trips returned from the API
  public trips: any[] = [];

  // Stores only the trips currently displayed after filtering
  public filteredTrips: any[] = [];

  // Stores the user's search text
  public searchTerm: string = '';

  ngOnInit(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: any) => {
        this.trips = value;
        this.filteredTrips = [...value];
      },
      error: (err) => {
        console.error('Error loading trips:', err);
      }
    });
  }

  /**
   * Filters trips based on the user's search text.
   * Searches the trip name, destination, and description.
   */
  filterTrips(): void {

    const search = this.searchTerm.toLowerCase().trim();

    if (search === '') {
      this.filteredTrips = [...this.trips];
      return;
    }

    this.filteredTrips = this.trips.filter(trip =>
      trip.name?.toLowerCase().includes(search) ||
      trip.destination?.toLowerCase().includes(search) ||
      trip.description?.toLowerCase().includes(search)
    );
  }

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }
}