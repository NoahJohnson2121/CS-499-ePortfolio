export const trips = [
  {
    code: 'CUN01',
    name: 'Cancun',
    length: '7 nights',
    resort: 'Beach Resort',
    perPerson: '$1200',
    image: 'reef1.jpg',
    description: 'Enjoy beautiful beaches, nightlife, and ocean views in Cancun.'
  },
  {
    code: 'HAW01',
    name: 'Hawaii',
    length: '5 nights',
    resort: 'Island Resort',
    perPerson: '$1800',
    image: 'reef2.jpg',
    description: 'Relax in tropical paradise with volcano tours and ocean adventures.'
  }
];