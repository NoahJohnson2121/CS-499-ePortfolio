const express = require('express');
const router = express.Router();
const ctrlTrips = require('../controllers/trips');
const jwt = require('jsonwebtoken');
const authController = require('../controllers/authentication');


/**
 * JWT Authentication Middleware
 * Protects routes that modify trip data.
 */
function authenticateJWT(req, res, next) {

    const authHeader = req.headers.authorization;


    if (!authHeader) {

        return res.status(401).json({
            message: 'Unauthorized'
        });

    }


    const token = authHeader.split(' ')[1];


    jwt.verify(
        token,
        process.env.JWT_SECRET,
        (err, decoded) => {


            if (err) {

                return res.status(401).json({
                    message: 'Invalid token'
                });

            }


            req.user = decoded;

            next();

        }
    );

}


// Authentication routes
router.post('/register', authController.register);
router.post('/login', authController.login);


// Trip retrieval routes
router.get('/trips', ctrlTrips.tripsList);

/*
 * CS-499 Algorithm Enhancement:
 * Search trips by name, resort, or description.
 *
 * Example:
 * GET /trips/search?query=Hawaii
 */
router.get('/trips/search', ctrlTrips.tripsSearch);


router.get('/trips/:tripCode', ctrlTrips.tripsFindCode);


// Protected trip modification routes
router.post(
    '/trips',
    authenticateJWT,
    ctrlTrips.tripsAddTrip
);


router.put(
    '/trips/:tripCode',
    authenticateJWT,
    ctrlTrips.tripsUpdateTrip
);


router.delete(
    '/trips/:tripCode',
    authenticateJWT,
    ctrlTrips.tripsDeleteTrip
);


module.exports = router;