const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
    name: String,
    email: {
        type: String,
        unique: true
    },
    hash: String,
    salt: String
});

userSchema.methods.setPassword = function(password) {

    this.salt = crypto.randomBytes(16).toString('hex');

    this.hash = crypto.pbkdf2Sync(
        password,
        this.salt,
        1000,
        64,
        'sha512'
    ).toString('hex');
};

userSchema.methods.validPassword = function(password) {

    const hash = crypto.pbkdf2Sync(
        password,
        this.salt,
        1000,
        64,
        'sha512'
    ).toString('hex');

    return this.hash === hash;
};

userSchema.methods.generateJwt = function() {

    return jwt.sign(
        {
            email: this.email
        },
        process.env.JWT_SECRET,
        {
            expiresIn: '7d'
        }
    );
};

mongoose.model('users', userSchema);