/**
 * Authentication Controller
 *
 * Handles user registration and login authentication
 * for the Travlr Getaways API.
 *
 * Improvements:
 * - Added input validation
 * - Improved error handling
 * - Added consistent API responses
 * - Improved maintainability and documentation
 *
 * Author: Noah Johnson
 * Course: CS-499
 */

const mongoose = require('mongoose');
const passport = require('passport');

const User = mongoose.model('users');


/**
 * POST /api/register
 *
 * Creates a new user account and returns
 * a JWT token after successful registration.
 */
const register = async (req, res) => {

    try {

        // Validate required registration fields
        if (!req.body.name || !req.body.email || !req.body.password) {

            return res.status(400).json({
                success: false,
                message: 'Name, email, and password are required.'
            });

        }


        const user = new User();

        user.name = req.body.name.trim();
        user.email = req.body.email.trim().toLowerCase();

        user.setPassword(req.body.password);


        await user.save();


        const token = user.generateJwt();


        return res.status(201).json({

            success: true,
            message: 'User registered successfully.',
            token

        });


    } catch (err) {

        console.error('Registration error:', err);


        return res.status(400).json({

            success: false,
            message: 'Unable to register user.',
            error: err.message

        });

    }

};



/**
 * POST /api/login
 *
 * Authenticates an existing user and
 * returns a JWT token.
 */
const login = (req, res) => {


    passport.authenticate(

        'local',

        (err, user) => {


            if (err) {

                console.error('Login error:', err);

                return res.status(500).json({

                    success: false,
                    message: 'Authentication error.',
                    error: err.message

                });

            }


            if (!user) {

                return res.status(401).json({

                    success: false,
                    message: 'Invalid email or password.'

                });

            }


            const token = user.generateJwt();


            return res.status(200).json({

                success: true,
                message: 'Login successful.',
                token

            });

        }

    )(req, res);

};



module.exports = {

    register,
    login

};