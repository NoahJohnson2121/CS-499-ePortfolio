const mongoose = require('mongoose');

const dbURI = 'mongodb://127.0.0.1:27017/travlr';

// Connect to MongoDB
mongoose.connect(dbURI)
    .then(() => {
        console.log(`MongoDB connected successfully at ${dbURI}`);
    })
    .catch((err) => {
        console.error('MongoDB connection error:', err);
    });

// Connection events (good practice for grading)
mongoose.connection.on('connected', () => {
    console.log('Mongoose connected to database');
});

mongoose.connection.on('error', (err) => {
    console.log('Mongoose connection error:', err);
});

mongoose.connection.on('disconnected', () => {
    console.log('Mongoose disconnected');
});

// Load models
require('../models/trips');
require('../../app_api/models/users');