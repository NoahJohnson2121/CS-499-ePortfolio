/**
 * Main Application Routes
 *
 * Handles customer-facing routes for the Travlr Getaways
 * web application.
 *
 * Author: Noah Johnson
 * Course: CS-499
 */

const express = require('express');

const router = express.Router();


/**
 * GET /
 *
 * Displays the Travlr Getaways homepage.
 */
router.get('/', (req, res) => {

    try {

        res.render('index', {
            title: 'Travlr Getaways'
        });

    } catch (err) {

        console.error('Error loading homepage:', err);

        res.status(500).send({
            success: false,
            message: 'Unable to load homepage.'
        });

    }

});


module.exports = router;