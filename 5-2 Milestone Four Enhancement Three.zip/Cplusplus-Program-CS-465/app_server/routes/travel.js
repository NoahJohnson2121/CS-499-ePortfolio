const express = require('express');
const router = express.Router();

const Trip = require('../models/trips');

router.get('/', async (req, res) => {
    try {
        const trips = await Trip.find({});
        res.render('travel', { trips });
    } catch (err) {
        res.status(500).json(err);
    }
});

// EDIT SCREEN
router.get('/edit/:code', async (req, res) => {
    const trip = await Trip.findOne({ code: req.params.code });

    res.render('edit-trip', { trip });
});

// UPDATE
router.post('/edit/:code', async (req, res) => {
    await Trip.findOneAndUpdate(
        { code: req.params.code },
        req.body
    );

    res.redirect('/travel');
});

module.exports = router;