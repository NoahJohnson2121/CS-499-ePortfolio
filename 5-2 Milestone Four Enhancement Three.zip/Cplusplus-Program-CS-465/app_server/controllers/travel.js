const travel = async (req, res) => {

    try {

        const response = await fetch(
            'http://localhost:3000/api/trips'
        );

        const trips = await response.json();

        res.render('travel', {
            title: 'Travlr Getaways',
            trips
        });

    } catch (err) {

        console.error(err);

        res.status(500).send(
            'Error retrieving trips'
        );

    }
};

module.exports = { travel };