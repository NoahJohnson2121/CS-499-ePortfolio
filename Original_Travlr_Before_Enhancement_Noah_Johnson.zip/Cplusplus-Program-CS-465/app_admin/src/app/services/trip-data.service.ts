import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  private url = 'http://localhost:3000/api/trips';

  constructor(
    private http: HttpClient,
    private auth: AuthenticationService
  ) {}

  private getHeaders() {
    const token = this.auth.getToken();

    return {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`
      })
    };
  }

  getTrips() {
    return this.http.get(this.url, this.getHeaders());
  }

  getTripByCode(code: string) {
    return this.http.get(`${this.url}/${code}`, this.getHeaders());
  }

  addTrip(trip: any) {
    return this.http.post(this.url, trip, this.getHeaders());
  }

  updateTrip(code: string, trip: any) {
    return this.http.put(`${this.url}/${code}`, trip, this.getHeaders());
  }

  deleteTrip(code: string) {
    return this.http.delete(`${this.url}/${code}`, this.getHeaders());
  }
}