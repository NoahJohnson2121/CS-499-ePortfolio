const Trip = require('../../app_server/models/trips');

// GET all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({});
        res.status(200).json(trips);
    } catch (err) {
        res.status(500).json(err);
    }
};

// GET one trip
const tripsFindCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({ code: req.params.tripCode });

        if (!trip) {
            return res.status(404).json({ message: 'Trip not found' });
        }

        res.status(200).json(trip);
    } catch (err) {
        res.status(500).json(err);
    }
};

// CREATE trip
const tripsAddTrip = async (req, res) => {
    try {
        const trip = await Trip.create(req.body);
        res.status(201).json(trip);
    } catch (err) {
        res.status(400).json(err);
    }
};

// UPDATE trip (FIXED)
const tripsUpdateTrip = async (req, res) => {
    try {
        const updated = await Trip.findOneAndUpdate(
            { code: req.params.tripCode },
            { $set: req.body },
            {
                new: true,
                runValidators: true
            }
        );

        if (!updated) {
            return res.status(404).json({ message: "Trip not found" });
        }

        res.status(200).json(updated);

    } catch (err) {
        res.status(400).json(err);
    }
};

// DELETE trip
const tripsDeleteTrip = async (req, res) => {
    try {
        const result = await Trip.deleteOne({ code: req.params.tripCode });

        res.status(200).json(result);
    } catch (err) {
        res.status(400).json(err);
    }
};

module.exports = {
    tripsList,
    tripsFindCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};