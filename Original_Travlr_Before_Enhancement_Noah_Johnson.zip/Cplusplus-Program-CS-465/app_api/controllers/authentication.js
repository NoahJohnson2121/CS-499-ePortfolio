const mongoose = require('mongoose');
const passport = require('passport');

const User = mongoose.model('users');

const register = async (req, res) => {

    try {

        const user = new User();

        user.name = req.body.name;
        user.email = req.body.email;

        user.setPassword(req.body.password);

        await user.save();

        const token = user.generateJwt();

        res.status(200).json({
            token
        });

    } catch (err) {

        res.status(400).json(err);

    }
};

const login = (req, res) => {

    passport.authenticate(
        'local',
        (err, user) => {

            if (err) {
                return res.status(404).json(err);
            }

            if (user) {

                const token = user.generateJwt();

                return res.status(200).json({
                    token
                });
            }

            return res.status(401).json({
                message: 'Unauthorized'
            });
        }
    )(req, res);
};

module.exports = {
    register,
    login
};