const express = require('express');
const router = express.Router();
const ctrlTrips = require('../controllers/trips');
const jwt = require('jsonwebtoken');
const authController = require('../controllers/authentication');

function authenticateJWT(req, res, next) {

    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({
            message: 'Unauthorized'
        });
    }

    const token = authHeader.split(' ')[1];

    jwt.verify(
        token,
        process.env.JWT_SECRET,
        (err, decoded) => {

            if (err) {
                return res.status(401).json({
                    message: 'Invalid token'
                });
            }

            req.user = decoded;

            next();
        }
    );
}

router.post('/register', authController.register);
router.post('/login', authController.login);

router.get('/trips', ctrlTrips.tripsList);
router.get('/trips/:tripCode', ctrlTrips.tripsFindCode);

router.post(
    '/trips',
    authenticateJWT,
    ctrlTrips.tripsAddTrip
);

router.put(
    '/trips/:tripCode',
    authenticateJWT,
    ctrlTrips.tripsUpdateTrip
);

router.delete(
    '/trips/:tripCode',
    authenticateJWT,
    ctrlTrips.tripsDeleteTrip
);

module.exports = router;