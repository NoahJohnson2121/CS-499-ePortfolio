/**
 * Trip Controller
 *
 * Handles all CRUD operations for the Travlr Getaways API.
 * Refactored to improve readability, maintainability,
 * validation, and error handling.
 *
 * Author: Noah Johnson
 * Course: CS-499
 */

const Trip = require('../../app_server/models/trips');

/**
 * GET /api/trips
 * Returns all trips.
 */
const tripsList = async (req, res) => {
    try {

        const trips = await Trip.find({});

        return res.status(200).json({
            success: true,
            count: trips.length,
            data: trips
        });

    } catch (err) {

        console.error('Error retrieving trips:', err);

        return res.status(500).json({
            success: false,
            message: 'Unable to retrieve trips.',
            error: err.message
        });

    }
};

/**
 * GET /api/trips/:tripCode
 * Returns one trip by its code.
 */
const tripsFindCode = async (req, res) => {

    try {

        const trip = await Trip.findOne({
            code: req.params.tripCode
        });

        if (!trip) {

            return res.status(404).json({
                success: false,
                message: 'Trip not found.'
            });

        }

        return res.status(200).json({
            success: true,
            data: trip
        });

    } catch (err) {

        console.error('Error retrieving trip:', err);

        return res.status(500).json({
            success: false,
            message: 'Unable to retrieve trip.',
            error: err.message
        });

    }

};

/**
 * POST /api/trips
 * Creates a new trip.
 */
const tripsAddTrip = async (req, res) => {

    try {

        const trip = await Trip.create(req.body);

        return res.status(201).json({
            success: true,
            message: 'Trip created successfully.',
            data: trip
        });

    } catch (err) {

        console.error('Error creating trip:', err);

        return res.status(400).json({
            success: false,
            message: 'Unable to create trip.',
            error: err.message
        });

    }

};

/**
 * PUT /api/trips/:tripCode
 * Updates an existing trip.
 */
const tripsUpdateTrip = async (req, res) => {

    try {

        const updatedTrip = await Trip.findOneAndUpdate(

            {
                code: req.params.tripCode
            },

            {
                $set: req.body
            },

            {
                new: true,
                runValidators: true
            }

        );

        if (!updatedTrip) {

            return res.status(404).json({
                success: false,
                message: 'Trip not found.'
            });

        }

        return res.status(200).json({
            success: true,
            message: 'Trip updated successfully.',
            data: updatedTrip
        });

    } catch (err) {

        console.error('Error updating trip:', err);

        return res.status(400).json({
            success: false,
            message: 'Unable to update trip.',
            error: err.message
        });

    }

};

/**
 * DELETE /api/trips/:tripCode
 * Deletes a trip by its code.
 */
const tripsDeleteTrip = async (req, res) => {

    try {

        const deletedTrip = await Trip.deleteOne({
            code: req.params.tripCode
        });

        if (deletedTrip.deletedCount === 0) {

            return res.status(404).json({
                success: false,
                message: 'Trip not found.'
            });

        }

        return res.status(200).json({
            success: true,
            message: 'Trip deleted successfully.'
        });

    } catch (err) {

        console.error('Error deleting trip:', err);

        return res.status(400).json({
            success: false,
            message: 'Unable to delete trip.',
            error: err.message
        });

    }

};

module.exports = {
    tripsList,
    tripsFindCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};